Project MUST be at "I:/csc3067-2021-g32"(for directory references)

Presentation:
https://docs.google.com/presentation/d/1VhPntCqoQkBYXj5uvGZMXzzXafzX_JTJdX-E6yKeg6s/edit#slide=id.ga153c15d28_1_18

Report:
https://qubstudentcloud-my.sharepoint.com/:w:/g/personal/40198194_ads_qub_ac_uk/EQ0nMgwo6J5CrHLFxFNixU4BIwJAxR-keLXcddwXLaTbWA?e=Z7eZUN