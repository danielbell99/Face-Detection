function K_trap        = BuildTrapScale(nbapp)

K_trap = [randn(nbapp,10) ];%rand(nbapp,10)];